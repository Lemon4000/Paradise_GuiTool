文件：params.xlsx（建议放置于本目录），或使用提供的 CSV 模板。

Excel 每个组使用一个 Sheet（例如：A组）。列名如下：
- Key（如 A0..A19）
- Name（显示名称，可自定义）
- Unit（单位）
- Min（最小值）
- Max（最大值）
- Precision（小数位数）
- Default（默认值）
- Description（说明）

如果不使用 Excel，可直接编辑本目录中的 A组.csv 与 Protocol.csv，程序会自动读取。
